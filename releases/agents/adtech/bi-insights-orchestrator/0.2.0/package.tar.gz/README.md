# BI Insights Orchestrator

Agent template for orchestrating cross-source BI insight generation in
marketing analytics.

## What this agent does

- Pulls data from multiple sources for fixed date windows.
- Normalizes KPI definitions across sources.
- Surfaces anomalies and insight candidates.
- Routes approved outputs into dashboard-ready reporting flows.

## Operational metadata

- Role: analytics orchestration agent for warehouse-backed BI reporting
- Autonomy level: semi-autonomous
- Approval boundary: may coordinate read-only analysis and draft reporting outputs; require human approval before any publish or stakeholder-distribution decision
- Outputs:
  - normalized KPI table
  - anomaly summary with evidence
  - publish recommendation
  - risks and data limitations

## Before you start

1. Install this agent package.
2. The installer resolves and pins the declared skill and tool packages.
3. Follow the generated `.runtime/<runtime>.json` readiness hints to configure
   GA4 and BigQuery credentials and targets.
4. Confirm your data sources are reachable. The bundled memory and governance
   profiles are used without manual binding edits.

Install commands (Codex example):

```bash
./bin/skills-hub install \
  --module agents \
  --entry adtech/bi-insights-orchestrator@latest \
  --runtime codex

```

## First run (copy/paste prompt)

```text
Use the BI Insights Orchestrator for:
- Current window: 2026-02-23 to 2026-03-01
- Previous window: 2026-02-16 to 2026-02-22
- Sources: GA4, BigQuery, Meta Ads

Required output:
1) Normalized KPI table (CTR, CPC, CPA, ROAS, CVR)
2) Top anomalies with evidence
3) Publish recommendation (approved or blocked)
4) Risks and data limitations
```

## What good output looks like

- Includes explicit metric formulas.
- Separates observed facts from hypotheses.
- Shows evidence values for anomalies.
- Includes a clear publish recommendation.

## Beginner safety checklist

- Start read-only for all data tools.
- Ask the agent to show limitations if any source fails.
- Require QA approval before any publish recommendation.

## Production preflight command

```bash
./bin/skills-hub run-agent \
  --agent adtech/bi-insights-orchestrator \
  --runtime codex \
  --approve-live \
  --audit-log ./tmp/bi-insights-orchestrator-run.json
```
